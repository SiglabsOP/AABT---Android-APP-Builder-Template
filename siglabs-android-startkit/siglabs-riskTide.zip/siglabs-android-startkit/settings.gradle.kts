pluginManagement {
    repositories {
        gradlePluginPortal()
        google()
        mavenCentral()
    }
}

plugins {
    id("com.highcapable.sweetdependency") version "1.0.4"
    id("com.highcapable.sweetproperty") version "1.0.5"
}

sweetProperty {
    rootProject { all { isEnable = false } }
}

rootProject.name = "siglabs-riskTide"
include(":app")
