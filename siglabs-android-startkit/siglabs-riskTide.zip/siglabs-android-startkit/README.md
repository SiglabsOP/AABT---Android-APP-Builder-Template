# android-app-template

 

A template for creating your own android APPS in android studio  
Do whatever you want with it. How about that.
peter
  
   This template doesnt include Jetpack however compileSdk has been updated to 35 and the code has been cleaned.
   and the template is fully functional december 2024
   
   
   
   (c) siglabs
   
   https://peterdeceuster.uk/doc/code-terms
   
   