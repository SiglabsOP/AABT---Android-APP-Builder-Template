plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    compileSdk = 34  // Make sure to use the latest SDK version

    namespace = "com.risktide.siglabs"  // Add your app's package name here

    defaultConfig {
        applicationId = "com.risktide.siglabs"  // Your app's package name
        minSdk = 21  // Minimum SDK version
        targetSdk = 34  // Target SDK version
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false  // Disable code shrinking for now
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.activity:activity:1.7.2")  // Essential for any Android app
    implementation("com.google.android.material:material:1.9.0")  // Optional for UI elements

    // Test dependencies
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

    // Remove Compose dependencies (if they were added in your template):
    // implementation("androidx.compose.ui:ui:1.5.0")
    // implementation("androidx.compose.material3:material3:1.0.0")
    // implementation("androidx.compose.foundation:foundation:1.5.0")
    // implementation("androidx.activity:activity-compose:1.7.0")
}
